#include <memory>
#include <queue>
#include <mutex>
#include <condition_variable>

template<typename T>
class SafeQueue {
	std::queue<T> m_queue;
	std::mutex m_mtx;
	std::condition_variable m_cond;
	bool m_isStopped {false};
public:
	// ~SafeQueue();
	void stop();
	void push(T& value);
	std::shared_ptr<T> wait_and_pop();
};