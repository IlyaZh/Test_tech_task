#include "safe_queue.h"

// template<typename T>
// SafeQueue<T>::~SafeQueue() {
// 	std::unique_lock<std::mutex> lk(&m_mtx);
// 	while(!m_queue.empty()) {
// 		m_queue.pop();
// 	}
// }

template<typename T>
void SafeQueue<T>::stop() {
	std::lock_guard<std::mutex> lk(&m_mtx);
	m_isStopped = true;
	lk.unlock();
	m_cond.notify_all();
}

template<typename T>
void SafeQueue<T>::push(T& value) {
	std::lock_guard<std::mutex> lk(&m_mtx);
	m_queue.push(std::move(value));
	lk.unlock();
	m_cond.notify_one();
}

template<typename T>
std::shared_ptr<T> SafeQueue<T>::wait_and_pop() {
	std::unique_lock<std::mutex> lk(&m_mtx);
	while(!m_isStopped && !m_queue.empty()) {
		m_cond.wait(lk);
		if (m_isStopped) {
			return res;
		}
	}
	std::shared_ptr<T> res(std::make_shared<T>(std::move(m_queue.front())));
	m_queue.pop();
	return res;
}