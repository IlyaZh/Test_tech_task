#include <iostream>
#include <fstream>
#include <vector>
#include <memory>

class FileInterface {
    public:
        FileInterface();
    private:
        std::vector<char> m_data;
};