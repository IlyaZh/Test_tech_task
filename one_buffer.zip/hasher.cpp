#include <iostream>
#include "hasher.h"
#include "config.h"
#include <fstream>
#include "file_handler.h"
#include <thread>
#include <future>
#include "crc8.hpp"

bool Hasher::start(std::shared_ptr<Config> config) {
    auto inFile = std::make_shared<FileHandler>(config->inputFilePath, config->blockSize);
    try {
        inFile->open();
    } catch(const std::exception& e) {
        std::cout << "[in] " << e.what() << " size=" << inFile->fileSize() << std::endl;
        throw;
    }

    const size_t sizeOutFile = ((inFile->fileSize() % config->blockSize) == 0) 
                            ? inFile->fileSize() / config->blockSize
                            : inFile->fileSize() / config->blockSize + 1;
    auto outFile = std::make_shared<FileHandler>(config->outputFilePath, config->blockSize, FileHandler::OpenMode::ReadWrite);
    try {
        outFile->open(sizeOutFile);
    } catch(const std::exception& e) {
        std::cout << "[out] " << e.what() << " size=" << outFile->fileSize() << std::endl;
        throw;
    }

    const size_t totalChunks = ((inFile->fileSize() % config->blockSize) == 0) 
        ? inFile->fileSize() / config->blockSize
        : inFile->fileSize() / config->blockSize + 1; // абсолютное количество блоков в файле
    const size_t chunks = ((inFile->size() % config->blockSize) == 0) 
        ? inFile->size() / config->blockSize 
        : inFile->size() / config->blockSize + 1; // количество блоков в текущем буфере
    std::cout << "chunks=" << chunks << std::endl;
    const size_t maxThreadsCount = std::max(1u, std::thread::hardware_concurrency()); // максимальное количество аппаратных потоков или выбираем 1
    const size_t threadsCount = std::min(chunks, maxThreadsCount); // количество потоков, которое будем использовать. Зачем нам потоки сверх количества блоков?

    std::vector<std::thread> threads;
    for(size_t i = 0; i < threadsCount-1; ++i) {
        threads.emplace_back(&Hasher::consumer, this, i, threadsCount, std::ref(inFile), config->blockSize, std::ref(outFile));
    }
    consumer(threadsCount-1, threadsCount, inFile, config->blockSize, outFile);

    for(auto& t : threads) {
        if(t.joinable())
            t.join();
    }
    return true;
}

void Hasher::reader(std::shared_ptr<std::fstream> input, const size_t blockSize) 
{

}
// Exception in threads.
void Hasher::consumer(const size_t idx, const size_t threadsCount, std::shared_ptr<FileHandler> input, const size_t blockSize, std::shared_ptr<FileHandler> out) {
    for(size_t offset = idx*blockSize; offset < input->size(); offset += blockSize*(threadsCount)) {
        const size_t n = offset / blockSize; // смещение ответа, т.к. результат хэш-функции = 1 байт, то определяем просто номером блока
        const char* buffer = (input->data())+offset;
        const size_t size = (offset+blockSize >= input->size()) 
                            ? input->size() - offset
                            : blockSize;
        auto res = crc8(buffer, size);
        try {
            out->write(res, n);
        } catch(std::exception& e) {
            std::cout << idx << e.what() << std::endl;
        }
    }
}


