#include <iostream>
#include <string>
#include <fstream>

using namespace std;
using ull_t = unsigned long long;

int main(int argc, char* argv[]) {
	if(argc != 3) {
		cout << "[ERROR] Wrong arguments count. Use generator.exe <file name> <size in bytes>" << endl;
	} else {
		std::string fileName(argv[1]);
		ull_t size = 0;
		try {
			size = stoull(string(argv[2]));
		} catch(std::exception& e) {
			cout << "[ERROR] Wring argument. Can't be converted to int: " << e.what() << endl;
		}
		fstream file(fileName, ios::binary | ios::out | ios::trunc);
		if(!file) {
			cout << "[ERROR] Something went wrong, Cannot open the file" << endl;
		} else {
			file.seekp(size-1);
			file.write("", 1);
			file.close();
		}
	}
}