#include "file_handler.h"
#include <iostream>
#include <fstream>
#include "config.h"
//#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mutex>
#include <algorithm>
//#include <sys/mman.h>
#include <boost/iostreams/device/mapped_file.hpp>

using namespace boost::iostreams;

// https://stackoverflow.com/questions/26252893/read-till-end-of-a-boost-memory-mapped-file-in-vc
// https://www.boost.org/doc/libs/1_77_0/libs/iostreams/doc/classes/mapped_file.html#mapped_file

FileHandler::FileHandler(const std::string& filePath, size_t blockSize, OpenMode mode) :
	m_filePath(filePath),
	m_blockSize(blockSize),
	m_start(0),
	m_fileSize(0),
	m_file(std::make_unique<mapped_file>())
	// m_bufferSize(0),
	// m_buffer(nullptr),
	// m_fs(std::make_unique<std::fstream>())
{
	m_mode = (mode == OpenMode::Read) 
				? mapped_file_base::mapmode::readonly 
				: mapped_file_base::mapmode::readwrite;

	if(mode == OpenMode::ReadWrite) {
		std::fstream f(m_filePath, std::ios::binary | std::ios::out);
	}
	
}

FileHandler::~FileHandler() {
	if(m_file->is_open())
		m_file->close();
}

void FileHandler::open(size_t length) {
	auto newLength = mapped_file::max_length;
	
	switch(m_mode) {
		case mapped_file_base::mapmode::readonly:
			do {
				std::cout << m_filePath << " S=" << newLength << std::endl;
				try {
					m_file->open(
						m_filePath,
						m_mode,
						newLength
					);
				} catch(std::exception&e) {
					
				}
				newLength /= 2;
			} while(!m_file->is_open() && newLength >= m_blockSize);
		break;

		case mapped_file_base::mapmode::readwrite:
			mapped_file_params params(m_filePath);
			params.mode = m_mode;
			m_fileSize = length;
			params.new_file_size = m_fileSize;
			params.length = m_fileSize;
			m_file->open(params);
		break;
	}
	std::error_code errCode;
	m_fileSize = std::filesystem::file_size(m_filePath, errCode);
	if(errCode) {
		m_fileSize = 0;
	}
	
	if(!m_file->is_open()) {
		throw std::invalid_argument("Can't open file " + m_filePath); // проверь исключение или получше подобрать?
	}}

const char* FileHandler::data() const {
	return m_file->const_data();
}

size_t FileHandler::size() const {
	return m_file->size();
}

void FileHandler::write(char value, size_t pos) {
	if(m_mode == mapped_file_base::mapmode::readwrite) {
		if(pos >= m_file->size()) {
			throw std::out_of_range("File write position is out of range");
		}
		std::unique_lock lk(m_mtx);
		m_file->data()[pos] = value;
	}
}

// const char* FileHandler::begin() const {
// 	return m_start;
// }

// const char* FileHandler::end() const {
// 	return m_start+m_bufferSize;
// }

// std::shared_ptr<char[]> FileHandler::read(size_t offset, size_t count) {
// 	std::unique_lock<std::mutex> lk(m_mtx);
// 	const size_t size = std::min(count, static_cast<size_t>(m_fs->tellg()) - offset);
// 	if(size > 0) {
// 		auto retArr = std::make_shared<char>(size);
// 		m_fs->seekg(offset);
// 		char* s = new char[size];
// 		m_fs->read(s, count);
// 		// return retArr;
// 	}
// 	return std::shared_ptr<char[]>();
// }

// std::filebuf* FileHandler::get() const {
// 	return m_fs->rdbuf();
// }

// size_t FileHandler::bufferSize() const {
// 	return m_bufferSize;
// }

size_t FileHandler::fileSize() const {
	return m_fileSize;
}

bool FileHandler::isWholeFile() const {
	return (m_start+m_file->size() == m_fileSize);
}

bool FileHandler::hasNextMap(size_t pos) const {
	return m_fileSize > (m_start+pos);
}

void FileHandler::nextMap(size_t pos) {
	if(m_start + pos >= m_fileSize) {
		const auto newStart = m_start + (pos & ~mapped_file::alignment()); // 
		if(m_start != newStart) {
			m_start = newStart;
			m_file->close();
			auto newSize = m_fileSize - m_start;
			do {
				try {
					m_file->open(m_filePath, m_mode, newSize, m_start);
				} catch(std::exception& e) {

				}
				newSize /= 2;
			} while(!m_file->is_open() && newSize >= m_blockSize);
			if(!m_file->is_open()) {
				throw std::invalid_argument("Can't open file " + m_filePath); // проверь исключение или получше подобрать?
			}
		}
	} else {
		throw std::overflow_error("File buffer wrong shift value " + m_filePath);
	}
}
