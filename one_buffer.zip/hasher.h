#pragma once

#include <memory>
#include <vector>
#include <thread>
#include <utility>
#include "safe_queue.h"

struct Config;
class FileHandler;

// struct Task {
//         Task(size_t from, size_t to) : start(from), end(to) {}
//         size_t start {0};
//         size_t end {0};
//     };

typedef std::pair<size_t, size_t> Task;

class Hasher {
public:
    Hasher() = default;
    bool start(std::shared_ptr<Config> config);
    // void consumer(const size_t blockSize, SafeQueue<Task>& queue);
    void consumer(const size_t idx, const size_t threadsCount,  std::shared_ptr<FileHandler> input, const size_t blockSize, std::shared_ptr<FileHandler> out);
private:
    static const size_t HashSize {1};

    SafeQueue<Task> m_queue;
    void reader(std::shared_ptr<std::fstream> input, const size_t blockSize); 
};